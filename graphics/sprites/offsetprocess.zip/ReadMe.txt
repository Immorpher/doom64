To run this software you will need ".NET core 3.1 32 bit" which you can get here: https://dotnet.microsoft.com/en-us/download/dotnet/thank-you/sdk-3.1.426-windows-x86-installer

Place original PNG sprites with offsets in the "Original" folder, then the edited PNGs go in the "Edited" folder. Then run "Process.bat" to add the offsets from the original sprites to the edited sprites of the same name.

SetPNG by Randy Heit: https://zdoom.org/w/index.php?title=SetPNG
OffsetSaver by Accensus: https://forum.zdoom.org/viewtopic.php?style=14&t=68329