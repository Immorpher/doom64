OffsetSaver save Original offsets.txt
OffsetSaver restore Edited offsets.txt